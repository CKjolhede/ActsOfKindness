<?php
require_once("doppelme.php");

//Your partner credentials
$doppelme_partner_id = 1;
$doppelme_partner_key = 'abcdefg';


//Set up 
$doppelme_api = new DoppelMe($doppelme_partner_id, $doppelme_partner_key);     


//Your user's unique id. Hardcoded here for this demo
$my_user_id = '1';



//Get avatar details for your user (this would normally be retreived from your db for your user)
if (isset( $_SESSION["DoppelMeKey"]) {
	//user already has an avatar registered with your account - redirect them to the editor
	header( 'Location: editor.php' );  
} 


//user input
if ( isset($_REQUEST["create_new"] ) ) {
	$CREATE_NEW    = $_REQUEST["create_new"];
} else {
	$CREATE_NEW    = "";
}
if ( isset($_REQUEST["avatar_name"] ) ) {
	$AVATAR_NAME    = $_REQUEST["avatar_name"];
} else {
	$AVATAR_NAME    = "";
}    
if ( isset($_REQUEST["doppelmekey"] ) ) {
	$DOPPELME_KEY = $_REQUEST["doppelmekey"];
} else {
	$DOPPELME_KEY = "";
}    
if ( isset($_REQUEST["username"] ) ) {
	$USERNAME    = $_REQUEST["username"];
} else {
	$USERNAME     = "";
}
if ( isset($_REQUEST["shadowkey"] ) ) {
	$SHADOW_KEY    = $_REQUEST["shadowkey"];
} else {
	$SHADOW_KEY    = "";
}    


echo'aa';
die();

if ($CREATE_NEW == "Y" and $AVATAR_NAME != "") {
	//user has requested to create a new avatar
	$details = $doppelme_api->create_user_account($my_user_id, $AVATAR_NAME);
	$status = $details['StatusCode'];
	if ($status != 0 ) {
		echo 'There has been a problem';
		die();
	} else {
		$doppelme_key = $details['DoppelMeKey'];
		//store this key with your users details so that you have their avatar available (use session here just for demo)
		$_SESSION["DoppelMeKey"] = $doppelme_key; 
		header( 'Location: ./done.php' ); 
	}

} elseif ($USERNAME != "") {
	//user already has an existing avatar that they want to use on your site
	//so we show them a list of all their avatars that they own and ask them 
	//to choose which on to use on your site
	
	$details = $doppelme_api->assign_user_id($my_user_id, $USERNAME, $SHADOW_KEY);
	$status = $details['StatusCode'];
	if ($status != 0 ) {
		echo 'There has been a problem';
		die();
	} else {				
		$selection = '';
		foreach($details['DoppelMeNames'] as $dm) {
			
			$key = $dm['key'];
			$name = $dm['name'];
			$select = '<input type="radio" name="doppelme_key" value="' . $name . '" >';
			$icon = '<img src="http://www.doppelme.com/' . $key . '/cropb.png">';
			
			$selection .= '<td>' . $icon . '<br>' . $select  . '</td>';			
		}
		$selection = '<table><tr>' . $selection . '</tr></table>';
		
	}
	
	
} elseif ( $DOPPELME_KEY != "" ) {	
	//user has selected one of their pre-existing avatars to use on your site
	
	//for the demo we save it in the session, but you should store it in your db for this user
	$_SESSION["DoppelMeKey"] = $DOPPELME_KEY; 
	header( 'Location: done.php' ); 	
}

?>  
<html>
<head>
</head>
<body>
    
        <?php if ($selection) { ?>
            Choose which of your avatars you want to use on this site
            <form action="create.php" method="post" >
			
            <?php echo $selection; ?> 
			<input type="submit" value="select">
            </form>
        <?php } else { ?>

            <h3>Create a new DoppelMe Avatar</h3>
            <form action="create.php" method="post">
            <table width="400">
            <tr><td colspan="2">
            Design your own avatar now. We use the <a href="http://www.doppelme.com">DoppelMe Avatar Engine</a> to create and manage avatars.
            </td></tr>
            <tr><td>Choose name for avatar <input type="text" name="avatar_name" value=""></td></tr>
            <tr><td colspan="2" align="center">
            <input type="hidden" name="create_new" value="Y" >
            <input type="submit"  value="Create New Avatar&gt;" >
            </td></tr>
            </table>
            </form>


            <br>
            <h3>Already Have a DoppelMe Avatar?</h3>
            <form action="create.php" method="post" >
            <table width="400">
            <tr><td colspan="2">If you already have an avatar from DoppelMe, you can use it on this site too. 
            Your shadow key can be obtained from the <strong>settings</strong> page on the <a href="http://www.doppelme.com">DoppelMe site</a>.
            <tr><td>doppelme username    </td><td> <input type="text" name="username" ></td></tr>
            <tr><td>doppelme shadow key    </td><td> <input type="text" name="shadowkey" ></td></tr>
            <tr><td colspan="2" align="center"><input type="submit" value="Use this avatar &gt; " ></td></tr>
            </table>
            <br><br>


        <?php }?>
    
</body>        
</html>    


