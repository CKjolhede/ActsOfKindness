<?php
//simple landing page after user has edited their avatar.


//this is only for demo. don't pass keys like this - you should already
//have your users id and doppelme key in your session
if (isset($_REQUEST['key']) && $_REQUEST['key'] != "") {
	echo '<img src="http://www.doppelme.com/' . $_REQUEST['key'] . '/avatar.png">';
	echo '<br>';	
	echo '<a href="editor.php">edit avatar</a>';
} else {
	echo "Invalid avatar key";
}


?>
