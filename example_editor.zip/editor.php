<?php

require_once("doppelme.php");

//Your partner credentials
$doppelme_partner_id = 1;
$doppelme_partner_key = 'abcdefg';


//Set up 
$doppelme_api = new DoppelMe($doppelme_partner_id, $doppelme_partner_key);     


//Your user's unique id
$my_user_id = '1';



//Get avatar details for your user
$details = $doppelme_api->get_user_details($my_user_id);
$status = $details['StatusCode'];
if ($status != 0) {
	//user does not have an avatar, so redirect them to a page where they can create one
	header( 'Location: ./create.php' );  
} 


$validation_key = $details['ValidationKey'];
$doppelme_key = $details['DoppelMeKey'];


//When a user finishes editing their avatar, send them back to this page
$callback_url = "http://localhost/done.php?key=" . $doppelme_key;

$language = 'EN';

//create the link to the editor
$editor_url = "http://api.doppelme.com/partner/partner_validate.asp?pid=%d&puid=%s&doppelmekey=%s&validkey=%s&callback=%s&lang=%s";
$editor_url = sprintf($editor_url, $doppelme_partner_id, $my_user_id, $doppelme_key, $validation_key, $callback_url, $language);


?>
<iframe src="<?php echo @$editor_url; ?>" 
    style="position:absolute;overflow:hidden;width:660px;height:450px;border: 0;border-collapse: collapse;margin: 0 auto;" 
    frameborder="0" marginwidth="0" marginheight="0" scrolling="no" vspace="5" hspace = "0"></iframe>
               


